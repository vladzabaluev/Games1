# Known issues

- The **Post Processing** package doesn't work on MacOS X 10.11.6 when running Metal in the editor due to a driver bug on this specific version of the OS.

For limitations and known issues for each effect, see the specific effect page.
